MADISON PROFILE — clean rebuilt package

Important fixes in this build:
- No loading screen at all, so the page cannot get stuck on a spinner.
- New local avatar filename: assets/avatar-madison-v2.png
- New local album-art filename: assets/album-envy-the-leaves.png
- New local MP3 filename: assets/envy-the-leaves.mp3
- New localStorage version key, so older broken saved paths do not override this build.
- Background is exactly #aac6d1 when no background video is set.
- TikTok is display-only (@pd) and has no URL/action.
- Discord copies madisonbeer.
- Telegram opens https://t.me/eviltriad.
- The avatar decoration loads only after the profile is visible and times out quickly if Discord CDN is unavailable, so it cannot hold the page open forever.

SECRET PANEL
1. Click the word "madison" three times quickly.
2. Type AHMED (case-insensitive).

GitHub Pages upload:
Upload the CONTENTS of this folder to the repo root, preserving the assets folder.
